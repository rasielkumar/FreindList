// Zu Beginn Import Anweisungen
// 1) import-Anweisungen
import Navigation from "./Navigation"


export default function App() {
  return  <Navigation />
  
  
}


