import { ActivityIndicator , StyleSheet, Text, View, Button, FlatList } from 'react-native';
import FriendListItem from '../components/FriendListItem';
import { useEffect, useState } from 'react';


export default function HomeScreen({ navigation }) {
  const [data, setData] = useState([]);
  const [isLoading, setLoading] = useState(true);

  async function fettchData() {
    setLoading(true);
    try {
    const response = await fetch('https://randomuser.me/api?results=50');
    const json = await response.json();
    setData(json.results);
    setLoading(false);
  } catch (error){
    alert('fehler beim Laden');
    setLoading(false);
  }
  setLoading(false);

}

  useEffect(() => {
    // Daten Laden
    fettchData();


  }, []);
  if(isLoading) {
  return (<View style={styles.center}>
    <ActivityIndicator size="large" color="darkorange"/>
    </View>
  );
  }
  return (
    <View style={styles.container}>
      <FlatList
        data={data}
        renderItem={({ item }) => (
          <FriendListItem
            friend={item}
            onPress={() =>
              navigation.navigate('Friend', { friend: item })
            }
          />

        )}

        keyExtractor={(item) => item.email}
        refreshing={isLoading}
        onRefresh={fettchData}
        ItemSeparatorComponent={<View style={styles.
          listSeparator} />}
        ListEmptyComponent={
          <Text style={styles.listEmpty}>Keine Daten geladen</Text>
        }
      />

    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',

    padding: 50,
  },
  listSeparator: {
    height: StyleSheet.hairlineWidth, backgroundColor: 'lightsalmon',
  },
  listEmpty: {
    fontSize: 32,
    paddingTop: 100,
    textAlign: 'center',
  },

  center:{
    felex: 1,
    justifyContent: 'center',
    alignItems: 'center,'
  }
});
